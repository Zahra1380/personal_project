from django.apps import AppConfig


class AboutAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'about_app'
    vebose_name = 'resumee'